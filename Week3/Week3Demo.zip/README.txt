External Resources

Consult the W3School Reference on HTML Elements: https://www.w3schools.com/tags/default.asp

Free stock videos: https://videos.pexels.com/

Version: 1/18/2019 EP

